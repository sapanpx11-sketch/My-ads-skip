package com.anarbastanov.adskipper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ClickerAccessibilityService : AccessibilityService() {

    // Only react while the requested quiz app is the active app.
    private val targetPackage = "com.quiz.earn.money.game"

    private val actionTexts = setOf(
        "Skip", "Skip ad", "Skip Ads", "SKIP AD", "Close", "Close ad",
        "Dismiss", "Dismiss ad", "No thanks", "Not now"
    )

    private val closeDescriptions = setOf(
        "Close", "Close ad", "Close advertisement", "Dismiss", "Dismiss ad",
        "Close ad panel", "Skip ad", "Skip Ads", "Skip"
    )

    // Mute-related labels are checked separately and only labels that imply
    // turning sound OFF are included, so an already-muted ad is not unmuted.
    private val muteTexts = setOf("Mute", "Mute ad", "Sound off", "Turn sound off")
    private val muteDescriptions = setOf("Mute", "Mute ad", "Sound off", "Turn sound off")

    private var lastScanAt = 0L
    private val scanCooldownMs = 250L
    private var lastClickAt = 0L
    private val clickDebounceMs = 800L
    private var lastMuteAt = 0L
    private val muteDebounceMs = 3_000L

    private val tmpRect = Rect()
    private val tapPath = Path()

    override fun onServiceConnected() {
        serviceInfo = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_WINDOWS_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            notificationTimeout = 100
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            packageNames = arrayOf(targetPackage)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() != targetPackage) return

        val now = SystemClock.uptimeMillis()
        if (now - lastScanAt < scanCooldownMs) return
        lastScanAt = now

        val root = rootInActiveWindow ?: return
        try {
            // Priority 1: dismiss/skip the ad or reward panel.
            if (now - lastClickAt >= clickDebounceMs && findAndClickAction(root)) {
                lastClickAt = now
                return
            }

            // Priority 2: mute only when a clear "turn sound off" control is exposed.
            if (now - lastMuteAt >= muteDebounceMs && findAndClickMute(root)) {
                lastMuteAt = now
            }
        } catch (_: RuntimeException) {
            // Accessibility windows may disappear while being scanned.
        }
    }

    override fun onInterrupt() = Unit

    private fun findAndClickAction(root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            if (node.isVisibleToUser) {
                val text = node.text?.toString()?.trim()
                val description = node.contentDescription?.toString()?.trim()
                if (text in actionTexts || description in closeDescriptions) {
                    if (clickNodeOrParent(node)) return true
                }
            }
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return false
    }

    private fun findAndClickMute(root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            if (node.isVisibleToUser) {
                val text = node.text?.toString()?.trim()
                val description = node.contentDescription?.toString()?.trim()
                if (text in muteTexts || description in muteDescriptions) {
                    if (clickNodeOrParent(node)) return true
                }
            }
            for (i in 0 until node.childCount) node.getChild(i)?.let(queue::add)
        }
        return false
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        var hops = 0
        while (current != null && hops++ < 6) {
            if (current.isVisibleToUser && current.isEnabled && current.isClickable &&
                current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            ) return true
            current = current.parent
        }

        // Fallback: tap the center only for a node explicitly identified by
        // its accessibility text or content description above.
        node.getBoundsInScreen(tmpRect)
        if (tmpRect.isEmpty) return false
        tapPath.rewind()
        tapPath.moveTo(tmpRect.exactCenterX(), tmpRect.exactCenterY())
        val stroke = GestureDescription.StrokeDescription(tapPath, 0, 10)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }
}
